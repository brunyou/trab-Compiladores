// Digite seu código C++ aqui
#include <iostream>
int main() {
  std::cout << "Olá do C++!" << std::endl;
  return 0;
}